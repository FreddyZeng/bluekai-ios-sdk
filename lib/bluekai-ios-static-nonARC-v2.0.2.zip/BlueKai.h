/*
 * Copyright 2013-present BlueKai, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@protocol BlueKaiOnDataPostedListener <NSObject>

- (void)onDataPosted:(BOOL)status;

@end

@interface BlueKai : NSObject <UIWebViewDelegate, UIGestureRecognizerDelegate, NSURLConnectionDelegate, NSURLConnectionDataDelegate> {
}

/** Sets a delegate for callbacks from the BlueKai SDK
* Works in conjunction with the `onDataPosted` method
*/
#if !__has_feature(objc_arc)
@property (nonatomic) id <BlueKaiOnDataPostedListener> delegate;
#else
@property (nonatomic,weak) id <BlueKaiOnDataPostedListener> delegate;
#endif

/** Sets iOS app version
*
* @param version, version of your iOS application
*/
@property (nonatomic) NSString *appVersion;

/** Sets development mode
*
* @param mode, turns on/off verbose logging with visual confirmation of params sent; defaults to "NO"
*/
@property (nonatomic) BOOL devMode;

/** Sets Apple IDFA id
* @param idfa, IDFA (Identifier for Advertising) id from Apple
*/
@property (nonatomic) NSString *idfa;

/** Sets user opt-in preference
*
* This replaces the deprecated "setPreference" method
*
* @param pref, sets user tracking preference; defaults to "YES"
*/
@property (nonatomic) BOOL optInPreference;

/** Sets BlueKai siteId
*
* @param id, contact your BlueKai rep for this id
*/
@property (nonatomic) NSString *siteId;

/** Sets User Agent string used for request to BlueKai
 *
 * @param userAgent, this is a default user agent that can be obtained from UIWebView or Mobile browser
 */
@property (nonatomic) NSString *userAgent;

/** Sets HTTPS transfer protocol
*
* @param BOOL, sets HTTPS; defaults to "NO"
*/
@property (nonatomic) BOOL useHttps;

/** Sets ViewController
*
* @param ViewController, set the ViewController instance as view to get notification on the data posting status
*/
@property (nonatomic) UIViewController *viewController;

/** Sets a preference towards direct HTTP calls vs Web View
 *
 * @param useDirectHTTPCalls
 */
@property (nonatomic) BOOL useDirectHTTPCalls;


/** This is the RECOMMENDED method for sending data
 *
 * Init BlueKai SDK using a UIWebView with Automatically Getting IDFA from the device
 *
 * useHTTPS is set to true by default.
 *
 * Create the instance for BlueKai SDK with required arguments and automatically grab the IDFA if
 * ad tracking is enabled on the device. IDFA is set to nil internally if ad tracking is disabled.
 *
 * @param siteId, contact your BlueKai rep for this id; required
 * @param appVersion, version of your iOS application; required
 * @param userAgent, browser user agent string (default user agent from Safari or UIWebView), optional
 * @param devMode, BOOL value to toggle on/off verbose logging; defaults to "NO"; optional
 */
- (id)initAutoIdfaEnabledWithSiteId:(NSString *)siteID
      withAppVersion:(NSString *)version
      withView:(UIViewController *)view
      withDevMode:(BOOL)devMode;


/** Init BlueKai SDK with IDFA
 *
 *  This method is OK to use if the host app is going to provide the IDFA
 *
 *  Create the instance for BlueKai SDK with required arguments and IDFA
 *
 * @param siteId, contact your BlueKai rep for this id; required
 * @param appVersion, version of your iOS application; required
 * @param idfa, IDFA (identifier for advertising) advertiser id from Apple, required
 * @param viewController, a view for the SDK to attach itself to for an invisible webView to call BlueKai tags with; required
 * @param devMode, BOOL value to toggle on/off verbose logging; defaults to "NO"; optional
 */
- (id)initWithSiteId:(NSString *)siteID
      withAppVersion:(NSString *)version
            withIdfa:(NSString *)idfa
            withView:(UIViewController *)view
         withDevMode:(BOOL)devMode;


/** Init BlueKai SDK
*
* Create the instance for BlueKai SDK with required arguments
*
* @param siteId, contact your BlueKai rep for this id; required
* @param appVersion, version of your iOS application; required
* @param viewController, a view for the SDK to attach itself to for an invisible webView to call BlueKai tags with; required
* @param devMode, BOOL value to toggle on/off verbose logging; defaults to "NO"; optional
*/
- (id)initWithSiteId:(NSString *)siteID
      withAppVersion:(NSString *)version
            withView:(UIViewController *)view
         withDevMode:(BOOL)devMode;


/** This is the ALTERNATIVE BUT NOT RECOMMENDED method of sending data
 * 
 * Init BlueKai SDK with a direct connection using NSURLConnection with Automatically Getting IDFA from the device
 *
 * useHTTPS is set to true by default.
 *
 * Create the instance for BlueKai SDK with required arguments and automatically grab the IDFA if
 * ad tracking is enabled on the device. IDFA is set to nil internally if ad tracking is disabled.
 *
 * @param siteId, contact your BlueKai rep for this id; required
 * @param appVersion, version of your iOS application; required
 * @param userAgent, browser user agent string (default user agent from Safari or UIWebView), optional
 * @param devMode, BOOL value to toggle on/off verbose logging; defaults to "NO"; optional
 */
- (id)initDirectAutoIdfaEnabledWithSiteId:(NSString *)siteID
                           withAppVersion:(NSString *)version
                              withDevMode:(BOOL)devMode;

/** Init BlueKai with IDFA and no web view
 *
 * Create the instance for BlueKai SDK with required arguments and IDFA
 *
 * This method is OK to use if the host app is going to provide the IDFA
 *
 * @param siteId, contact your BlueKai rep for this id; required
 * @param appVersion, version of your iOS application; required
 * @param idfa, IDFA (identifier for advertising) advertiser id from Apple, required
 * @param devMode, BOOL value to toggle on/off verbose logging; defaults to "NO"; optional
 */
- (id)initDirectWithSiteId:(NSString *)siteID
            withAppVersion:(NSString *)version
                  withIdfa:(NSString *)idfa
               withDevMode:(BOOL)devMode;


/** Sets URL params by using NSDictionary
 *
 * @param dictionary, key/value pairs to be constructed as URL params
 */
- (void)updateWithDictionary:(NSDictionary *)dictionary;


/** Sets URL params as a key/value pair
*
* @param key, URL param key; required
* @param value, URL param value; required
*/
- (void)updateWithKey:(NSString *)key
             andValue:(NSString *)value;


/** Resume BlueKai process
 *
 * Method to resume BlueKai process after calling application resumes or comes to foreground. To use in onResume() of the calling activity foreground.
 *
 */
- (void)resume;


/** DEPRECATED METHODS **/


/** Init BlueKai SDK (Deprecated)
 *
 * Deprecated; Use "initWithSiteId" instead
 *
 */
- (id)initWithArgs:(BOOL)value
        withSiteId:(NSString *)siteID
    withAppVersion:(NSString *)version
          withView:(UIViewController *)view __deprecated;

/** Sets URL params as a key/value pair
 *
 * Deprecated; use "updateWithKey:andValue" instead
 *
 * @param key, URL param key; required
 * @param value, URL param value; required
 */
- (void)put:(NSString *)key
  withValue:(NSString *)value __deprecated;

/** Sets URL params by using NSDictionary
*
* Deprecated; use "updateWithDictionary" instead
*
* @param dictionary, key/value pairs to be constructed as URL params
*/
- (void)put:(NSDictionary *)dictionary __deprecated;

/** Displays BlueKai Optout screen
*
* Deprecated; use the "setOptInPreference" property instead
*
* Displays a view to allow user to optout of tracking by BlueKai
*
*/
- (void)showSettingsScreen __deprecated;

/** Displays BlueKai Optout screen with option to set background color
*
* Deprecated; use the "setOptInPreference" property instead
*
* Same functionality as `showSettingsScreen` with option to set custom background color
*
* @param color, sets background color for settings UIViewController; defaults to `whiteColor`
*/
- (void)showSettingsScreenWithBackgroundColor:(UIColor *)color __deprecated;


@end
